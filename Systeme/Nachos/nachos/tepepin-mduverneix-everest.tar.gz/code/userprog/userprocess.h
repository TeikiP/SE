#ifdef CHANGED

static void StartUserProcess(void *schmurtz);

void do_ForkExec(const char *s);

#endif // CHANGED
