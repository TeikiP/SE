#ifdef CHANGED

#ifndef COPYSTRING_H
#define COPYSTRING_H

#include "copyright.h"
#include "utility.h"

int copyStringFromMachine(int from, char* to, unsigned int size);
int copyStringToMachine(char* from, int to, unsigned int size);

#endif // COPYSTRING_H
#endif // CHANGED

